import csms.user.User;
import csms.user.UserManager;

public class Main {

    public static void main(String[] args) {
	// write your code here
        UserManager um = new UserManager(100);

        um.addUser();
        um.showall();


    }
}

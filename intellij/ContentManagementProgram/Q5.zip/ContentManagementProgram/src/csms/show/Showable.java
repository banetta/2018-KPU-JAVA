package csms.show;

public interface Showable {

    public void showAll();
}

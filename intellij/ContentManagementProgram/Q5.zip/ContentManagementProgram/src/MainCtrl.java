public class MainCtrl {

    public static void main(String[] args) {
	// write your code here
        CSMS csms = new CSMS();

        csms.setDefault();
        csms.run();

    }
}

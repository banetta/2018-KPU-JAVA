package csms.download;

import csms.content.ContentManager;
import csms.user.User;
import csms.user.UserManager;

public class DownloadManager {

    private Download download[];
    private int index=0;

    public DownloadManager(int n){
        download = new Download[n];
    }

    public void addDownload(UserManager um, ContentManager cm){

        download[index++] = new Download(index, um.findUserByName("홍길동"), cm.findContentByTitle("전쟁과 평화"));
        download[index++] = new Download(index, um.findUserByName("일길동"), cm.findContentByTitle("그해 겨울"));
        download[index++] = new Download(index, um.findUserByName("이길동"), cm.findContentByTitle("미스터 선샤인 1화"));
        download[index++] = new Download(index, um.findUserByName("삼길동"), cm.findContentByTitle("미스터 선샤인 2화"));
        download[index++] = new Download(index, um.findUserByName("사길동"), cm.findContentByTitle("한끼줍쇼 100회"));
        download[index++] = new Download(index, um.findUserByName("오길동"), cm.findContentByTitle("걸어서 세계로 10회"));
    }
    public void showAll(){
        for (int i = 0; i < index; i++)
            System.out.println(download[i].toString());
    }
}

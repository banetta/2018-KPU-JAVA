package cms.contact;
import cms.contact.*;

public class BasicContact extends Contact{

    public BasicContact(String name, String email, String group){
        super(name, email, group);
    }
}

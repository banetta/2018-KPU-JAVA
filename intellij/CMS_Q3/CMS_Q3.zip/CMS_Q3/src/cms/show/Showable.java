package cms.show;

public class Showable {
}

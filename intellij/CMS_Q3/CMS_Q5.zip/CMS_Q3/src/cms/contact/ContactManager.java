package cms.contact;
import cms.group.GroupManager;

import java.util.Scanner;

public class ContactManager{

    Contact carr[];
    int index=0;
    Scanner sc;

    public ContactManager(int n)
    {
        carr = new Contact[n];
        sc = new Scanner(System.in);
    }

    public void addContact(GroupManager gm) {
        String name, email;
        int group;

        System.out.println("<<Contact 정보 입력>>");
        System.out.print(" - 이 름: "); name = sc.nextLine();
        System.out.print(" - 이메일: "); email = sc.nextLine();
        gm.showAll();
        System.out.print(" - 그 룹: "); group = sc.nextInt();

        carr[index++] = new Contact(name, email, gm.getTitle(group));
    }
    public void showAll() {
        System.out.println("------------------------------------------------");
        System.out.println("이름          이메일                 그룹");
        for(int i=0; i< index; i++)
            carr[i].showData();
        System.out.println("------------------------------------------------");
    }

    public void findContact(){
        String temp;
        String input;
        System.out.printf("검색 이름>> ");
        input = sc.nextLine();

        System.out.println("------------------------------------------------");
        System.out.println("이름          이메일                 그룹");
        System.out.println("------------------------------------------------");
        for(int i=0; i< index; i++) {
            temp = carr[i].getName();
            if (input.equals(temp))
                carr[i].showData();
        }
        System.out.println("Serch Complete");
        System.out.println("------------------------------------------------");

    }
}

import cms.contact.ContactManager;
import cms.group.GroupManager;


public class MainCtrl {

    public static void main(String[] args) {
        // write your code here
        ContactManager cm = new ContactManager(100);
        GroupManager gm = new GroupManager(100);
        MainMenu mm = new MainMenu();

        while (true) {
            switch (mm.IssueMenu()) {
                case 1:
                    cm.addContact();
                    break;

                case 2:
                    cm.findContact();
                    break;

                case 3:
                    cm.showAll();
                    break;

                case 4:
                    gm.addGroup();
                    break;

                case 5:
                    gm.showAll();
                    break;

                case 0:
                    System.out.println("Program exit");
                    return;

                default:
                    System.out.println("잘못 입력하였습니다.");
                    break;
            }
        }
    }
}

package cms.contact;

public class BasicContact {
}

package cms.contact;

public class FullContact {
}

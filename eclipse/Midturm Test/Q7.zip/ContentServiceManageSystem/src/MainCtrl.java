import csms.content.ContentManager;
import csms.download.DownloadManager;
import csms.user.UserManager;

public class MainCtrl {

	public static void main(String[] args) {
		// TODO �ڵ� ������ �޼ҵ� ����
		
		
		CSMS csms = new CSMS();
		
		csms.run();
		
		
		
		
		

	}

}

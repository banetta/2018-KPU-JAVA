import csms.content.ContentManager;
import csms.user.UserManager;

public class MainCtrl {

	public static void main(String[] args) {
		// TODO �ڵ� ������ �޼ҵ� ����
		
		ContentManager cm = new ContentManager(200);
		
		cm.setDefault();
		
		cm.showAll();
		
		

	}

}

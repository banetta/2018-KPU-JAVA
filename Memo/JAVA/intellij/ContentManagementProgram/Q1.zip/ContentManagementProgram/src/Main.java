import csms.user.User;

public class Main {

    public static void main(String[] args) {
	// write your code here
        User user = new User(1, "홍길동");

        user.showall();
    }
}
